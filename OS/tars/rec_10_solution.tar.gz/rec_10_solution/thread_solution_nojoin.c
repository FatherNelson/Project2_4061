#include <stdio.h>
#include <unistd.h>
#include <pthread.h>


int myturn = 0;
char *files[] = {"1.txt","2.txt"};
int i_am_done[2];

void * writefile(void *arg) {
	char buf[1024];
	int id = *(int *)arg;
	i_am_done[id] = 0;
	FILE * f = fopen(files[id],"r");
	
	while (i_am_done[id] == 0) {
		while (myturn != id){
			pthread_yield();
		       	// WAIT
		}
		char *r = fgets(buf,1024,f);
		if (r == NULL) {
			i_am_done[id] = 1;
		} else {
			printf("[%d]  %s",id,buf);
		}
		if (i_am_done[(id + 1) % 2] == 0) {
			myturn = (id + 1) % 2; 
		}
	}
	return NULL;
}

int main (int argc, char **argv) {
	
	pthread_t th1, th2;
	
	int id1=0,id2=1;

	/* Create thread */
	if (pthread_create(&th1,NULL,writefile,(void *)&id1) != 0) {
		perror("couldn't create thread");
	}
	
	if (pthread_create(&th2,NULL,writefile,(void *)&id2) != 0) {
		perror("couldn't create thread");
	}
	
	pthread_exit(NULL);
}

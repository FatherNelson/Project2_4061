#include<stdio.h> 
#include<stdlib.h> 
#include<sys/wait.h> 
#include<unistd.h> 

#define NUM 5000

int main() {
	pid_t cpid;
	int i;
	for (i = 0 ; i < NUM ; i++){
		cpid = fork();
		if (cpid == 0)
			break;
	}
	if (cpid != 0 ){
		for (i = 0 ; i < NUM ; i++){
			wait(NULL);
		}
	}
  
    return 0; 
} 

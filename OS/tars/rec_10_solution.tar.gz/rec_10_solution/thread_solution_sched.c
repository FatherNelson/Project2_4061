#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <sched.h>

char *files[] = {"1.txt","2.txt"};
int i_am_done[2];

void * writefile(void *arg) {
	char buf[1024];
	int id = *(int *)arg;
	i_am_done[id] = 0;
	FILE * f = fopen(files[id],"r");

	while (i_am_done[id] == 0) {
		char *r = fgets(buf,1024,f);
		if (r == NULL) {
			i_am_done[id] = 1;
		} else {
			printf("[%d]  %s",id,buf);
		}
		//usleep(500);
	}
	return NULL;
}

int main (int argc, char **argv) {
	
	pthread_t th1, th2;
	pthread_attr_t thread_attr;
	struct sched_param rr_param;

	pthread_attr_init(&thread_attr);	
	pthread_attr_setscope(&thread_attr, PTHREAD_SCOPE_PROCESS);
	pthread_attr_setschedpolicy(&thread_attr, SCHED_RR);

	int id1=0,id2=1;


	/* Create thread */
	if (pthread_create(&th1,&thread_attr,writefile,(void *)&id1) != 0) {
		perror("couldn't create thread");
	}
	
	if (pthread_create(&th2,&thread_attr,writefile,(void *)&id2) != 0) {
		perror("couldn't create thread");
	}
	
	/* Join threads */
	if (pthread_join(th1,NULL) != 0) {
		perror("couldn't join thread");
	} else {
		printf("joined thread 1\n");
	}
	
	if (pthread_join(th2,NULL) != 0){ 
		perror("couldn't join thread");
	} else {
		printf("joined thread 2\n");
	}
	
	return 0;
}

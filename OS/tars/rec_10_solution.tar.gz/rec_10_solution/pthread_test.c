#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#define NUM_THREADS 5000

void * func(void *threadid){
    pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
    pthread_t threads[NUM_THREADS];
    int rc, t;
    
    for (t=0;t<NUM_THREADS;t++) {
        rc = pthread_create(&threads[t], NULL, func, NULL);
        if (rc) {
            printf("ERROR; return code from pthread_create() is %d\n", rc);
            exit(-1);
        }
    }

    for (t=0;t<NUM_THREADS;t++) {
	    if (pthread_join(threads[t],NULL) != 0)
		    perror("couldn't join thread");
    }
    return 0;
}

#include <stdio.h>
#include <signal.h>
#include <stdlib.h>

int ALARMcount;

void AlarmSignalHandler(int sig) {

	//if another alarm occurs while in signal handler, ignore it
	signal(SIGALRM, SIG_IGN);

	//increment alarm counter

	//print "Woke up for the # time"

	//if count < 3 call alarm again
	if(ALARMcount < 3){


	}
	else {
		exit(0);
	}

	//reinstall the signal handler
}

int main(int argc, char*argv[]){

	//initialize counter
	ALARMcount = 0;

	//install signal handler for SIGALRM

	//call alarm(5)

	while(1);
	return 0;
}
